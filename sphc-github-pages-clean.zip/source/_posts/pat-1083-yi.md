---
title: PAT 1083.是否存在相等的差
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 247c340c
date: 2018-03-24 12:48:03
---

## 题目
给定 N 张卡片，正面分别写上 1、2、……、N，然后全部翻面，洗牌，在背面分别写上 1、2、……、N。将每张牌的正反两面数字相减（大减小），得到 N 个非负差值，其中是否存在相等的差？

**输入格式：**

输入第一行给出一个正整数 N（2 <= N <= 10000），随后一行给出 1 到 N 的一个洗牌后的排列，第 i 个数表示正面写了 i 的那张卡片背面的数字。

**输出格式：**

按照“差值 重复次数”的格式从大到小输出重复的差值及其重复的次数，每行输出一个结果。

**输入样例：**

8
3 5 8 6 2 1 4 7

**输出样例：**

5 2
3 3
2 2

## 我的解决方案
```cpp
#include <stdio.h>

#define SIZE 10010

//返回x的绝对值
int abs(int x)
{ return x >= 0 ? x : -x; }

int main(void)
{
    int n, max = -1; //max:最大差值
    int a[SIZE] = {0}; //下标保存差值,值为该差值出现的次数

    scanf("%d", &n);
    for (int i = 1; i <= n; ++i) {
        int x;

        scanf("%d", &x);
        x = abs(x - i);
        ++a[x];
        if (max < x) {
            max = x;
        }
    }

    while (max >= 0) {
        if (a[max] > 1) {
            printf("%d %d\n", max, a[max]);
        }
        --max;
    }

    return 0;
}
```
