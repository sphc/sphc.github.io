---
title: PAT 1060.爱丁顿数
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 8833d1ab
date: 2018-01-30 12:49:32
---
## 题目
英国天文学家爱丁顿很喜欢骑车。据说他为了炫耀自己的骑车功力，还定义了一个“爱丁顿数”E，即满足有E天骑车超过E英里的最大整数E。据说爱丁顿自己的E等于87。

现给定某人N天的骑车距离，请你算出对应的爱丁顿数E（<=N）。

**输入格式：**

输入第一行给出一个正整数N（<=10<sup>5</sup>），即连续骑车的天数；第二行给出N个非负整数，代表每天的骑车距离。

**输出格式：**

在一行中给出N天的爱丁顿数。

**输入样例：**

10
6 7 6 9 3 10 8 2 7 8

**输出样例：**

6

## 我的解决方案
```c
#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

//SIZE不开大点会造成段错误,应该是距离会大于10^5
#define SIZE 200010

int main(void)
{
    int n;
    int distance[SIZE] = {0}; //distance[i]表示骑车距离为i的天数
    int m[SIZE] = {0}; //m[i]代表骑车距离超过i的天数
    int max = INT_MIN; //最大距离

    //输入骑车天数及距离
    scanf("%d", &n);
    for (int i = 0; i < n; ++i) {
        int d;

        scanf("%d", &d);
        if (d > max) {
            max = d;
        }
        ++distance[d];
    }

    //求m
    //这里把i >= 0改成i > 0会有测试点过不去,坑
    for (int i = max; i >= 0; --i) {
        m[i] += m[i + 1] + distance[i + 1];
    }

    //m[i] >= i表示骑车距离超过i的天数 >= i天
    //从n天开始找,第一次找到m[i] >= i时即为E
    //这里把i >= 0改成i > 0会有测试点过不去,坑
    for (int i = n; i >= 0; --i) {
        //有E天骑车超过E英里,表示骑车超过E英里的天数大于等于E
        if (m[i] >= i) {
            printf("%d\n", i);
            break;
        }
    }

    return 0;
}

```
