---
title: PAT 1019.General Palindromic Number
mathjax: true
toc: true
categories: 'PAT题解[甲级]'
tags:
  - PAT
abbrlink: feb31050
date: 2018-02-08 22:52:05
---
## 题目
A number that will be the same when it is written forwards or backwards is known as a Palindromic Number. For example, 1234321 is a palindromic number. All single digit numbers are palindromic numbers.

Although palindromic numbers are most often considered in the decimal system, the concept of palindromicity can be applied to the natural numbers in any numeral system. Consider a number N > 0 in base b >= 2, where it is written in standard notation with k+1 digits a<sub>i</sub> as the sum of (a<sub>i</sub>b<sup>i</sup>) for i from 0 to k. Here, as usual, 0 <= a<sub>i</sub> < b for all i and a<sub>k</sub> is non-zero. Then N is palindromic if and only if a<sub>i</sub> = a<sub>k-i</sub> for all i. Zero is written 0 in any base and is also palindromic by definition.

Given any non-negative decimal integer N and a base b, you are supposed to tell if N is a palindromic number in base b.

**Input Specification:**

Each input file contains one test case. Each case consists of two non-negative numbers N and b, where 0 <= N <= 10<sup>9</sup> is the decimal number and 2 <= b <= 10<sup>9</sup> is the base. The numbers are separated by a space.

**Output Specification:**

For each test case, first print in one line "Yes" if N is a palindromic number in base b, or "No" if not. Then in the next line, print N as the number in base b in the form "a<sub>k</sub> a<sub>k-1</sub> ... a<sub>0</sub>". Notice that there must be no extra space at the end of output.

**Sample Input 1:**

27 2

**Sample Output 1:**

Yes
1 1 0 1 1

**Sample Input 2:**

121 5

**Sample Output 2:**

No
4 4 1

## 我的解决方案
```cpp
#include <iostream>
#include <list>
#include <vector>

//解题思路:
//1.将数字转换为base进制表示,结果存入一个vector中,
//其中vector的每一个元素为数字的一位,
//如: 200的160进制在vector中保存为: 1 40
//2.判断该vector保存的数是否回文

using namespace std;

//将num转换为base进制表示,结果存入result
void trans(int num, int base, vector<int> &result)
{
    list<int> tmp;

    if (num == 0) {
        tmp.push_front(num);
    }

    while (num) {
        tmp.push_front(num % base);
        num /= base;
    }
    for (list<int>::const_iterator i = tmp.cbegin(); i != tmp.cend(); ++i) {
        result.push_back(*i);
    }
}

//num是回文则返回true,否则返回false
bool isPalindromicity(const vector<int> &num)
{
    vector<int>::const_iterator i = num.cbegin(), j = num.cend() - 1;

    while (i < j && *i == *j) {
        ++i;
        --j;
    }

    return i >= j;
}

int main()
{
    int n, b;
    vector<int> result;

    cin >> n >> b;
    trans(n, b, result);
    cout << (isPalindromicity(result) ? "Yes" : "No") << endl;
    for (vector<int>::size_type i = 0; i < result.size(); ++i) {
        if (i) {
            cout << " ";
        }
        cout << result[i];
    }
    cout << endl;

    return 0;
}
```
