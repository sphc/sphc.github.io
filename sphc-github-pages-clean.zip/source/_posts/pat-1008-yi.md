---
title: PAT 1008.数组元素循环右移问题
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 2f56ee7e
date: 2018-01-21 17:02:14
---
## 题目
一个数组A中存有N（N>0）个整数，在不允许使用另外数组的前提下，将每个整数循环向右移M（M>=0）个位置，即将A中的数据由（A<sub>0</sub> A<sub>1</sub>……A<sub>N-1</sub>）变换为（A<sub>N-M</sub> …… A<sub>N-1</sub> A<sub>0</sub> A<sub>1</sub>……A<sub>N-M-1</sub>）（最后M个数循环移至最前面的M个位置）。如果需要考虑程序移动数据的次数尽量少，要如何设计移动的方法？

**输入格式：** 每个输入包含一个测试用例，第1行输入N ( 1<=N<=100)、M（M>=0）；第2行输入N个整数，之间用空格分隔。

**输出格式：** 在一行中输出循环右移M位以后的整数序列，之间用空格分隔，序列结尾不能有多余空格。

**输入样例：**

6 2
1 2 3 4 5 6

**输出样例：**
5 6 1 2 3 4

## 我的解决方案
```c
#include <stdio.h>

void swap(int *left, int *right)
{
    int x;

    x = *left;
    *left = *right;
    *right = x;
}

int main(void)
{
    int a[110];
    int n, m;

    scanf("%d%d", &n, &m);
    for (int i = 0; i < n; ++i) {
        scanf("%d", a + i);
    }
    m %= n;
    //当m <= n / 2时，可以用swap完成右移
    if (m <= n / 2) {
        for (int i = n - 1; i >= m; --i) {
            swap(a + i, a + (i + m) % n);
        }
    }
    else { //否则相当于左移n - m位
        m = n - m;
        for (int i = 0; i < n - m; ++i) {
            swap(a + i, a + (i - m + n) % n);
        }
    }
    for (int i = 0; i < n; ++i) {
        if (i) {
            putchar(' ');
        }
        printf("%d", a[i]);
    }
    putchar('\n');

    return 0;
}
```
