---
title: PAT 1077.Kuchiguse
mathjax: true
toc: true
categories: 'PAT题解[甲级]'
tags:
  - PAT
abbrlink: 3011bdb
date: 2018-04-15 09:47:34
---

## 题目
The Japanese language is notorious for its sentence ending particles. Personal preference of such particles can be considered as a reflection of the speaker's personality. Such a preference is called "Kuchiguse" and is often exaggerated artistically in Anime and Manga. For example, the artificial sentence ending particle "nyan~" is often used as a stereotype for characters with a cat-like personality:

* Itai nyan~ (It hurts, nyan~)
* Ninjin wa iyada nyan~ (I hate carrots, nyan~)

Now given a few lines spoken by the same character, can you find her Kuchiguse?

**Input Specification:**

Each input file contains one test case. For each case, the first line is an integer N (2<=N<=100). Following are N file lines of 0~256 (inclusive) characters in length, each representing a character's spoken line. The spoken lines are case sensitive.

**Output Specification:**

For each test case, print in one line the kuchiguse of the character, i.e., the longest common suffix of all N lines. If there is no such suffix, write "nai".

**Sample Input 1:**

3
Itai nyan~
Ninjin wa iyadanyan~
uhhh nyan~

**Sample Output 1:**

nyan~

**Sample Input 2:**

3
Itai!
Ninjinnwaiyada T_T
T_T

**Sample Output 2:**

nai

## 我的解决方案
```cpp
#include <iostream>
#include <stack>
#include <string>

//解题思路:
//先用一个变量保存第一个字符串
//然后每次与新的字符串取最长公共后缀,并更新之

using namespace std;

//获取最长公共后缀
string getMaxSuffix(const string left, const string right)
{
    string result;
    stack<char> s;

    for (auto i = left.crbegin(), j = right.crbegin(); 
            i != left.crend() && j != right.crend() && *i == *j; 
            ++i, ++j) {
        s.push(*i);
    }
    while (!s.empty()) {
        result.push_back(s.top());    
        s.pop();
    }

    return result;
}

int main()
{
    int n;
    string s, result;

    cin >> n;
    getline(cin, result); //读掉末尾的回车
    getline(cin, result); //第一行字符串
    while (--n) {
        getline(cin, s);
        result = getMaxSuffix(result, s);
    }

    cout << (!result.empty() ? result : "nai")  << endl;

    return 0;
}
```
