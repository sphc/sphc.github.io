---
title: PAT 1008.Elevator
mathjax: true
toc: true
categories: 'PAT题解[甲级]'
tags:
  - PAT
abbrlink: '92181795'
date: 2018-02-01 14:37:46
---
## 题目
The highest building in our city has only one elevator. A request list is made up with N positive numbers. The numbers denote at which floors the elevator will stop, in specified order. It costs 6 seconds to move the elevator up one floor, and 4 seconds to move down one floor. The elevator will stay for 5 seconds at each stop.

For a given request list, you are to compute the total time spent to fulfill the requests on the list. The elevator is on the 0th floor at the beginning and does not have to return to the ground floor when the requests are fulfilled.

**Input Specification:**

Each input file contains one test case. Each case contains a positive integer N, followed by N positive numbers. All the numbers in the input are less than 100.

**Output Specification:**

For each test case, print the total time on a single line.

**Sample Input:**

3 2 3 1

**Sample Output:**

41

## 我的解决方案
```cpp
#include <iostream>

//解题思路:
//模拟电梯运行过程

using namespace std;

int main()
{
    int n;
    int total = 0; //总时间
    int start = 0; //保存起始位置

    cin >> n;
    for (int i = 0; i < n; ++i) {
        int floor; //请求楼层

        cin >> floor;
        //电梯上升
        if (floor > start) {
            total += (floor - start) * 6 + 5;
        }
        else { //电梯下降
            total += (start - floor) * 4 + 5;
        }

        start = floor;
    }

    cout << total << endl;

    return 0;
}
```
