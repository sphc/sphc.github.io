---
title: PAT 1020.月饼
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 84f3683f
date: 2017-12-15 21:39:31
---
## 题目
月饼是中国人在中秋佳节时吃的一种传统食品，不同地区有许多不同风味的月饼。现给定所有种类月饼的库存量、总售价、以及市场的最大需求量，请你计算可以获得的最大收益是多少。

注意：销售时允许取出一部分库存。样例给出的情形是这样的：假如我们有3种月饼，其库存量分别为18、15、10万吨，总售价分别为75、72、45亿元。如果市场的最大需求量只有20万吨，那么我们最大收益策略应该是卖出全部15万吨第2种月饼、以及5万吨第3种月饼，获得 72 + 45/2 = 94.5（亿元）。

**输入格式：**

每个输入包含1个测试用例。每个测试用例先给出一个不超过1000的正整数N表示月饼的种类数、以及不超过500（以万吨为单位）的正整数D表示市场最大需求量。随后一行给出N个正数表示每种月饼的库存量（以万吨为单位）；最后一行给出N个正数表示每种月饼的总售价（以亿元为单位）。数字间以空格分隔。

**输出格式：**

对每组测试用例，在一行中输出最大收益，以亿元为单位并精确到小数点后2位。

**输入样例：**

3 20
18 15 10
75 72 45

**输出样例：**

94.50

## 我的解决方案
```c
#include <stdio.h>
#include <float.h>
#include <stdlib.h>

typedef struct {
    double weight; //库存
    double price;  //单价
} Moncake;

int cmp(const void *first, const void *second)
{
    const Moncake *moncake1 = first;
    const Moncake *moncake2 = second;
    double difference;
    
    difference = moncake2->price / moncake2->weight - 
                 moncake1->price / moncake1->weight;
    if (difference > FLT_EPSILON) {
        return 1;
    }
    else if (difference < -FLT_EPSILON) {
        return -1;
    }
    else {
        return 0;
    }
}

int main(void)
{
    int n, d; //n：月饼种数，d：市场最大需求量
    double result = 0;
    double currentWeight = 0;
    Moncake *moncakes;

    scanf("%d%d", &n, &d);
    //分配内存
    moncakes = (Moncake *)malloc(sizeof(Moncake) * n);
    //输入库存
    for (int i = 0; i < n; ++i) {
        scanf("%lf", &moncakes[i].weight);
    }
    //输入价格
    for (int i = 0; i < n; ++i) {
        scanf("%lf", &moncakes[i].price);
    }

    //按单价从大到小排序
    qsort(moncakes, n, sizeof(Moncake), cmp);
    //计算收益
    for (int i = 0; i < n; ++i) {
        //当前月饼总重量与之前已近选择的重量之和小于最大需求，则全部选择
        if (moncakes[i].weight + currentWeight <= d) {
            result += moncakes[i].price;
            currentWeight += moncakes[i].weight;
        }
        else { //否则选则可以达到最大需求的量
            result += (d - currentWeight) / moncakes[i].weight * moncakes[i].price;
            break;
        }
    }
    //输出结果
    printf("%.2f\n", result);

    return 0;
}
```
