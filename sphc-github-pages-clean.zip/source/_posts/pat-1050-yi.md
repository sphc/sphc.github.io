---
title: PAT 1050.螺旋矩阵
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 605874c5
date: 2018-01-30 11:17:45
---
## 题目
本题要求将给定的N个正整数按非递增的顺序，填入“螺旋矩阵”。所谓“螺旋矩阵”，是指从左上角第1个格子开始，按顺时针螺旋方向填充。要求矩阵的规模为m行n列，满足条件：m*n等于N；m>=n；且m-n取所有可能值中的最小值。

**输入格式：**

输入在第1行中给出一个正整数N，第2行给出N个待填充的正整数。所有数字不超过10<sup>4</sup>，相邻数字以空格分隔。

**输出格式：**

输出螺旋矩阵。每行n个数字，共m行。相邻数字以1个空格分隔，行末不得有多余空格。

**输入样例：**

12
37 76 20 98 76 42 53 95 60 81 58 93

**输出样例：**

98 95 93
42 37 81
53 20 76
58 60 76

## 我的解决方案
```c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define SIZE 10010

int matrix[SIZE][SIZE] = {0};

int cmp(const void *left, const void *right)
{ return *(int *)right - *(int *)left; }

//获取n和m的值
void getNM(int *n, int *m, int N) 
{
    int i = 1;
    int j = N / i;

    while (i <= N && i <= j) {
        if (i * j == N) {
            *n = i;
            *m = j;
        }
        j = N / ++i;
    }
}

int main(void)
{
    int N;
    int n, m;
    int nums[SIZE];
    int x = 0, y = 0;
    int cur = 0;

    //输入数字
    scanf("%d", &N);
    for (int i = 0; i < N; ++i) {
        scanf("%d", nums + i);
    }

    //非递增排序
    qsort(nums, N, sizeof(int), cmp);

    getNM(&n, &m, N);

    //填入第一个数
    matrix[x][y] = nums[cur++];
    while (cur < N) {
        //一直向右填到不能填为止
        while (y + 1 < n && !matrix[x][y + 1]) {
            matrix[x][++y] = nums[cur++];
        }

        //一直向下填到不能填为止
        while (x + 1 < m && !matrix[x + 1][y]) {
            matrix[++x][y] = nums[cur++];
        }

        //一直向左填到不能填为止
        while (y - 1 >= 0 && !matrix[x][y - 1]) {
            matrix[x][--y] = nums[cur++];
        }

        //一直向上填到不能填为止
        while (x - 1 >= 0 && !matrix[x - 1][y]) {
            matrix[--x][y] = nums[cur++];
        }
    }

    //打印矩阵
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            if (j) {
                printf(" ");
            }
            printf("%d", matrix[i][j]);
        }
        printf("\n");
    }

    return 0;
}
```
