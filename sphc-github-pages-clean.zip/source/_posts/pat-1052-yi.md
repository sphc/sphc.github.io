---
title: PAT 1052.卖个萌
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: a84d0f38
date: 2018-01-21 17:06:55
---
## 题目
萌萌哒表情符号通常由“手”、“眼”、“口”三个主要部分组成。简单起见，我们假设一个表情符号是按下列格式输出的：

左手(左眼 口 右眼)右手
现给出可选用的符号集合，请你按用户的要求输出表情。

**输入格式：**

输入首先在前三行顺序对应给出手、眼、口的可选符号集。每个符号括在一对方括号[]内。题目保证每个集合都至少有一个符号，并不超过10个符号；每个符号包含1到4个非空字符。

之后一行给出一个正整数K，为用户请求的个数。随后K行，每行给出一个用户的符号选择，顺序为左手、左眼、口、右眼、右手——这里只给出符号在相应集合中的序号（从1开始），数字间以空格分隔。

**输出格式：**

对每个用户请求，在一行中输出生成的表情。若用户选择的序号不存在，则输出“Are you kidding me? @\\/@”。

**输入样例：**

[╮][╭][o][~\][/~]  [<][>]
 [╯][╰][^][-][=][>][<][@][⊙]
[Д][▽][_][ε][^]  ...
4
1 1 2 2 2
6 8 1 5 5
3 3 4 3 3
2 10 3 9 3

**输出样例：**

╮(╯▽╰)╭
<(@Д=)/~
o(^ε^)o
Are you kidding me? @\\/@

## 我的解决方案
```c
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

const int SIZE = 12;

//读取一个字符集合
void getCollection(char s[][5], int *size)
{
    int c;
    int count = 0;

    while (true) {
        int i = 0;

        while ((c = getchar()) != EOF && c != '\n' && c != '[') {
        }
        if (c == EOF || c == '\n') {
            break;
        }
        while ((c = getchar()) != EOF && c != '\n' && c != ']') {
            s[count][i++] = c;
        }
        if (c == EOF || c == '\n') {
            break;
        }
        s[count][i] = '\0';
        ++count;
    }
    *size = count;
}

int main(void)
{
    char hand[SIZE][5];
    char eye[SIZE][5];
    char mouth[SIZE][5];
    int size1, size2, size3; //三个数组的元素个数
    int k;

    getCollection(hand, &size1);
    getCollection(eye, &size2);
    getCollection(mouth, &size3);

    scanf("%d", &k);
    while (k--) {
        int leftHand, rightHand;
        int leftEye, rightEye;
        int m;

        scanf("%d%d%d%d%d", &leftHand, &leftEye, &m, &rightEye, &rightHand);
        if (leftHand < 1 || leftHand > size1 || rightHand < 1 || 
            rightHand > size1 || leftEye < 1 || leftEye > size2 || 
            rightEye < 1 || rightEye > size2 || m < 1 || m > size3) {
            printf("Are you kidding me? @\\/@\n");
        }
        else {
            printf("%s(%s%s%s)%s\n", hand[leftHand - 1], eye[leftEye - 1], 
                    mouth[m - 1], eye[rightEye - 1], hand[rightHand - 1]);
        }
    }

    return 0;
}
```
