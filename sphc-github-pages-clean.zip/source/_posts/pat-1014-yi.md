---
title: PAT 1014.福尔摩斯的约会
categories: 'PAT题解[乙级]'
mathjax: true
toc: true
tags:
  - PAT
abbrlink: d022cde4
date: 2017-12-07 21:01:58
---
## 题目
大侦探福尔摩斯接到一张奇怪的字条：“我们约会吧！ 3485djDkxh4hhGE 2984akDfkkkkggEdsb s&hgsfdk d&Hyscvnm”。大侦探很快就明白了，字条上奇怪的乱码实际上就是约会的时间“星期四 14:04”，因为前面两字符串中第1对相同的大写英文字母（大小写有区分）是第4个字母'D'，代表星期四；第2对相同的字符是'E'，那是第5个英文字母，代表一天里的第14个钟头（于是一天的0点到23点由数字0到9、以及大写字母A到N表示）；后面两字符串第1对相同的英文字母's'出现在第4个位置（从0开始计数）上，代表第4分钟。现给定两对字符串，请帮助福尔摩斯解码得到约会的时间。

**输入格式：**

输入在4行中分别给出4个非空、不包含空格、且长度不超过60的字符串。

**输出格式：**

在一行中输出约会的时间，格式为“DAY HH:MM”，其中“DAY”是某星期的3字符缩写，即MON表示星期一，TUE表示星期二，WED表示星期三，THU表示星期四，FRI表示星期五，SAT表示星期六，SUN表示星期日。题目输入保证每个测试存在唯一解。

**输入样例：**
3485djDkxh4hhGE 
2984akDfkkkkggEdsb 
s&hgsfdk 
d&Hyscvnm

**输出样例：**
THU 14:04

## 我的解决方案
```c
#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>

//一周的表示
const char *week[7] = {"MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"};

//判断是否大写字母
bool isCapital(int c)
{ return c >= 'A' && c <= 'N'; }

void appointment(const char *s1, const char *s2, const char *s3, const char *s4)
{
    bool first = true; //是否是第一次
    const char *start = s3; //记录开始位置

    while (*s1 && *s2) {
        if (*s1 == *s2) {
            if (first && *s1 >= 'A' && *s1 <= 'G') { //满足第一个条件，打印星期
                printf("%s ", week[*s1 - 'A']);
                first = false;
            }
            else if (!first && (*s1 >= 'A' && *s1 <= 'N' || isdigit(*s1))) { //满足第二个条件，打印时钟
                printf("%.2d:", (isalpha(*s1)) ? *s1 - 'A' + 10 : *s1 - '0');
                break;
            }
        }
        ++s1;
        ++s2;
    }

    while (*s3 && *s4) {
        if (isalpha(*s3) && *s3 == *s4) { //满足第三个条件，打印秒钟
            printf("%.2d", (int)(s3 - start));
            break;
        }
        ++s3;
        ++s4;
    }
    putchar('\n');
}

int main(void)
{
    char s1[61], s2[61], s3[61], s4[61];

    scanf("%s%s%s%s", s1, s2, s3, s4);
    appointment(s1, s2, s3, s4);    

    return 0;
}
```
