---
title: PAT 1012.数字分类
categories: 'PAT题解[乙级]'
mathjax: true
toc: true
tags:
  - PAT
abbrlink: 95bf5e45
date: 2017-12-04 20:55:45
---
## 题目
给定一系列正整数，请按要求对数字进行分类，并输出以下5个数字：

* A1 = 能被5整除的数字中所有偶数的和；
* A2 = 将被5z除后余1的数字按给出的顺序进行交错求和，即计算n1-n2+n3-n4...；
* A3 = 被5除后余2的数字的个数；
* A4 = 被5除后余3的数字的平均数，精确到小数点后1位；
* A5 = 被5除后余4的数字中最大数字。

**输入格式：**

每个输入包含1个测试用例。每个测试用例先给出一个不超过1000的正整数N，随后给出N个不超过1000的待分类的正整数。数字间以空格分隔。

**输出格式：**

对给定的N个正整数，按题目要求计算A1~At并在一行中顺序输出。数字间以空格分隔，但行末不得有多余空格。若其中某一类数字不存在，则在相应位置输出"N"。

**输入样例1：**

13 1 2 3 4 5 6 7 8 9 10 20 16 18

**输出样例1：**

30 11 2 9.7 9

**输入样例2：**

8 1 2 4 5 6 7 9 16

**输出样例2：**

N 11 2 N 9

## 我的解决方案
```c
#include <stdio.h>
#include <stdbool.h>

int main(void)
{
    int n;
    int num;
    bool flag = false; //标记是否有A2
    int sym = 1; //符号位，用于计算A2
    int count = 0; //A4中数的个数
    int a[5] = {0}; // a[0]表示A1，a[1]表示A2...

    scanf("%d", &n);
    for (int i = 0; i < n; ++i) {
        scanf("%d", &num);
        //分类
        switch (num % 5) {
            case 0 : 
                if (num % 2 == 0) {
                    a[0] += num;
                }
                break;
            case 1 : 
                a[1] += sym * num;
                sym = -sym;
                flag = true;
                break;
            case 2 : 
                ++a[2];
                break;
            case 3 : 
                a[3] += num; //累加和
                ++count;     //计算个数，便于之后求平均值
                break;
            case 4 : 
                if (a[4] < num) {
                    a[4] = num;
                }
                break;
        }
    }
    for (int i = 0; i < 5; ++i) {
        if (i) { //除了第一个外，每个输出前打印一个空格
            putchar(' ');
        }
        if (i == 1) {
            if (flag) {
                printf("%d", a[i]);
            }
            else {
                putchar('N');
            }
        }
        else if (i == 3) {
            if (a[i] > 0) {
                printf("%.1f", (double)a[i] / count);
            }
            else {
                putchar('N');
            }
        }
        else {
            if (a[i] > 0) {
                printf("%d", a[i]);
            }
            else {
                putchar('N');
            }
        }
    }
    putchar('\n');

    return 0;
}
```
