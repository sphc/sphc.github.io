---
title: PAT 1005.Spell It Right
mathjax: true
toc: true
categories: 'PAT题解[甲级]'
tags:
  - PAT
abbrlink: 8241a5d8
date: 2018-02-01 14:37:38
---
## 题目
Given a non-negative integer N, your task is to compute the sum of all the digits of N, and output every digit of the sum in English.

**Input Specification:**

Each input file contains one test case. Each case occupies one line which contains an N (<= 10<sup>100</sup>).

**Output Specification:**

For each test case, output in one line the digits of the sum in English words. There must be one space between two consecutive words, but no extra space at the end of a line.

**Sample Input:**

12345

**Sample Output:**

one five

## 我的解决方案
```cpp
#include <iostream>
#include <string>

//解题思路:
//1.通过字符串数组保存单词,下标与词义对应
//2.递归打印sum,打印时输出与其对应的单词

using namespace std;

//单词数组
const char *words[] = { 
    "zero", "one", "two", "three", "four", 
    "five", "six", "seven", "eight", "nine"
};

void _printByWords(int num)
{
    if (num) {
        _printByWords(num / 10);
        cout << words[num % 10] << " ";
    }
}

//以单词形式打印num
void printByWords(int num)
{
    //这样调用仅仅为了控制格式
    _printByWords(num / 10);
    cout << words[num % 10];
}

int main()
{
    string num;
    int sum = 0;

    cin >> num;
    //累加每一个数的和
    for (const auto x : num) {
        sum += x - '0';
    }

    printByWords(sum);
    cout << endl;

    return 0;
}
```
