---
title: PAT 1061.判断题
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 69abe33a
date: 2017-12-28 18:46:04
---
## 题目
判断题的评判很简单，本题就要求你写个简单的程序帮助老师判题并统计学生们判断题的得分。

**输入格式：**

输入在第一行给出两个不超过100的正整数N和M，分别是学生人数和判断题数量。第二行给出M个不超过5的正整数，是每道题的满分值。第三行给出每道题对应的正确答案，0代表“非”，1代表“是”。随后N行，每行给出一个学生的解答。数字间均以空格分隔。

**输出格式：**

按照输入的顺序输出每个学生的得分，每个分数占一行。

**输入样例：**

3 6
2 1 3 3 4 5
0 0 1 0 1 1
0 1 1 0 0 1
1 0 1 0 1 0
1 1 0 0 1 1

**输出样例：**

13
11
12

## 我的解决方案
```c
#include <stdio.h>

int score[10000] = {0}; //每道题的满分值
int answer[10000] = {0}; //每道题的正确答案

int main(void)
{
    int n, m;

    scanf("%d%d", &n, &m);
    for (int i = 0; i < m; ++i) {
        scanf("%d", score + i);
    }
    for (int i = 0; i < m; ++i) {
        scanf("%d", answer + i);
    }
    for (int i = 0; i < n; ++i) {
        int grade = 0; //每个学生的得分
        int a; //每个答案

        for (int j = 0; j < m; ++j) {
            scanf("%d", &a);
            if (a == answer[j]) {
                grade += score[j];
            }
        }
        printf("%d\n", grade);
    }

    return 0;
}
```  
