---
title: PAT 1002.写出这个数
categories: 'PAT题解[乙级]'
mathjax: true
toc: true
tags:
  - PAT
abbrlink: 1eb9839a
date: 2017-11-28 20:46:32
---
## 题目
读入一个自然数n，计算其各位数字之和，用汉语拼音写出和的每一位数字。

**输入格式：** 每个测试输入包含1个测试用例，即给出自然数n的值。这里保证n小于10<sup>100</sup> 。

**输出格式：** 在一行内输出n的各位数字之和的每一位，拼音数字间有1空格，但一行中最后一个拼音数字后没有空格。

**输入样例：**

1234567890987654321123456789

**输出样例：**

yi san wu

## 我的解决方案
```c
#include <stdio.h>

const char *chineseNum[] = {"ling", "yi", "er", "san", "si", "wu", "liu", "qi", "ba", "jiu"};

//对数num的各位数字求和
int numSum(const char *num)
{
    int sum = 0;

    while (*num) {
        sum += *num - '0';
        ++num;
    }

    return sum;
}

//将数值以拼音形式输出
void proc(int value)
{
    if (value) {
        proc(value / 10);
        if (value / 10) { //若不是第一个数字，则在输出前加一个空格
            putchar(' ');
        }
        printf("%s", chineseNum[value % 10]);
    }
}

int main(void)
{
    char num[110];

    scanf("%s", num);
    proc(numSum(num));
    putchar('\n');

    return 0;
}
```
