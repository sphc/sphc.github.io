---
title: PAT 1043.输出PATest
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 27f49859
date: 2017-12-22 22:41:21
---
## 题目
给定一个长度不超过10000的、仅由英文字母构成的字符串。请将字符重新调整顺序，按“PATestPATest....”这样的顺序输出，并忽略其它字符。当然，六种字符的个数不一定是一样多的，若某种字符已经输出完，则余下的字符仍按PATest的顺序打印，直到所有字符都被输出。

**输入格式：**

输入在一行中给出一个长度不超过10000的、仅由英文字母构成的非空字符串。

**输出格式：**

在一行中按题目要求输出排序后的字符串。题目保证输出非空。

**输入样例：**

redlesPayBestPATTopTeePHPereatitAPPT

**输出样例：**

PATestPATestPTetPTePePee

## 我的解决方案
```c
#include <stdio.h>

int main(void)
{
    int count[6] = {0}; //用于统计各字符个数 
    int c;

    while ((c = getchar()) != EOF && c != '\n') {
        switch(c) {
            case 'P' : ++count[0]; break;
            case 'A' : ++count[1]; break;
            case 'T' : ++count[2]; break;
            case 'e' : ++count[3]; break;
            case 's' : ++count[4]; break;
            case 't' : ++count[5]; break;
        }
    }
    while (count[0] > 0 || count[1] > 0 || count[2] > 0 ||
           count[3] > 0 || count[4] > 0 || count[5] > 0) {
        if (count[0]-- > 0) {
            putchar('P');
        }
        if (count[1]-- > 0) {
            putchar('A');
        }
        if (count[2]-- > 0) {
            putchar('T');
        }
        if (count[3]-- > 0) {
            putchar('e');
        }
        if (count[4]-- > 0) {
            putchar('s');
        }
        if (count[5]-- > 0) {
            putchar('t');
        }
    }
    putchar('\n');

    return 0;
}
```
