---
title: PAT 1058.选择题
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: e9d17bd6
date: 2018-01-21 17:13:58
---
## 题目
批改多选题是比较麻烦的事情，本题就请你写个程序帮助老师批改多选题，并且指出哪道题错的人最多。

**输入格式：**

输入在第一行给出两个正整数N（<=1000）和M（<=100），分别是学生人数和多选题的个数。随后M行，每行顺次给出一道题的满分值（不超过5的正整数）、选项个数（不少于2且不超过5的正整数）、正确选项个数（不超过选项个数的正整数）、所有正确选项。注意每题的选项从小写英文字母a开始顺次排列。各项间以1个空格分隔。最后N行，每行给出一个学生的答题情况，其每题答案格式为“(选中的选项个数 选项1 ……)”，按题目顺序给出。注意：题目保证学生的答题情况是合法的，即不存在选中的选项数超过实际选项数的情况。

**输出格式：**

按照输入的顺序给出每个学生的得分，每个分数占一行。注意判题时只有选择全部正确才能得到该题的分数。最后一行输出错得最多的题目的错误次数和编号（题目按照输入的顺序从1开始编号）。如果有并列，则按编号递增顺序输出。数字间用空格分隔，行首尾不得有多余空格。如果所有题目都没有人错，则在最后一行输出“Too simple”。

**输入样例：**

3 4
3 4 2 a c
2 5 1 b
5 3 2 b c
1 5 4 a b d e
(2 a c) (2 b d) (2 a c) (3 a b e)
(2 a c) (1 b) (2 a b) (4 a b d e)
(2 b d) (1 e) (2 b c) (4 a b c d)

**输出样例：**

3
6
5
2 2 3 4

## 我的解决方案
```c
#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>
#include <string.h>

int findMax(const int *arr, int size)
{
    int max = 0;

    for (int i = 0; i < size; ++i) {
        if (max < arr[i]) {
            max = arr[i];
        }
    }

    return max;
}

//读取一行，丢弃末尾的换行
void getLine(char *s)
{
    int c;

    while ((c = getchar()) != EOF && c != '\n') {
        *s++ = c;
    }

    *s = '\0';
}

//输入一个学生的答案
void inputAnAnswer(char *choice)
{
    int c;

    while (isspace(c = getchar()) || c != '(') {
    }
    while ((c = getchar()) != ')') {
        *choice++ = c;
    }
    *choice = '\0';
}

int main(void)
{
    int n, m;
    char answer[120][30]; // 答案
    int grade[1010] = {0};
    int mistake[120] = {0}; //下标+1表示编号，值表示错误次数
    int max;

    scanf("%d%d", &n, &m);
    //将剩余空白读掉
    //这个地方用一个getchar会导致第一个案例过不去，用两个getchar会导致只有第一个案例能过
    getLine(answer[0]);
    for (int i = 0; i < m; ++i) {
        getLine(answer[i]);
    }

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            char choice[30]; //学生的选择

            inputAnAnswer(choice);
            //输入的答案的格式为：下标为0的值是满分，下标4开始是选项个数和答案
            //故从下标4开始比较相同后可知学生答题正确
            if (strcmp(answer[j] + 4, choice) == 0) {
                grade[i] += answer[j][0] - '0';
            }
            else {
                //统计错误次数
                ++mistake[j];
            }
        }
    }

    for (int i = 0; i < n; ++i) {
        printf("%d\n", grade[i]);
    }

    max = findMax(mistake, m);
    //max为0表示没有错误
    if (max == 0) {
        printf("Too simple");
    }
    else {
        printf("%d", max);
        for (int i = 0; i < m; ++i) {
            if (mistake[i] == max) {
                printf(" %d", i + 1);
            }
        }
    }
    putchar('\n');

    return 0;
}
```
