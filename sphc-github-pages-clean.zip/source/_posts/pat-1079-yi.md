---
title: PAT 1079.延迟的回文数
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: a5cf6012
date: 2018-01-01 23:17:19
---
## 题目
给定一个 k+1 位的正整数 N，写成 a<sub>k</sub>...a<sub>1</sub>a<sub>0</sub> 的形式，其中对所有 i 有 0 <= a<sub>i</sub> < 10 且 a<sub>k</sub> > 0。N 被称为一个回文数，当且仅当对所有 i 有 a<sub>i</sub> = a<sub>k</sub>-i。零也被定义为一个回文数。

非回文数也可以通过一系列操作变出回文数。首先将该数字逆转，再将逆转数与该数相加，如果和还不是一个回文数，就重复这个逆转再相加的操作，直到一个回文数出现。如果一个非回文数可以变出回文数，就称这个数为延迟的回文数。（ 定义翻译自`https://en.wikipedia.org/wiki/Palindromic_number`）

给定任意一个正整数，本题要求你找到其变出的那个回文数。

**输入格式：**

输入在一行中给出一个不超过1000位的正整数。

**输出格式：**

对给定的整数，一行一行输出其变出回文数的过程。每行格式如下

A + B = C
其中A是原始的数字，B是A的逆转数，C是它们的和。A从输入的整数开始。重复操作直到C在10步以内变成回文数，这时在一行中输出“C is a palindromic number.”；或者如果10步都没能得到回文数，最后就在一行中输出“Not found in 10 iterations.”。

**输入样例 1：**

97152

**输出样例 1：**

97152 + 25179 = 122331
122331 + 133221 = 255552
255552 is a palindromic number.

**输入样例 2：**

196

**输出样例 2：**

196 + 691 = 887
887 + 788 = 1675
1675 + 5761 = 7436
7436 + 6347 = 13783
13783 + 38731 = 52514
52514 + 41525 = 94039
94039 + 93049 = 187088
187088 + 880781 = 1067869
1067869 + 9687601 = 10755470
10755470 + 07455701 = 18211171
Not found in 10 iterations.

## 我的解决方案
```c
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

bool isPal(const char *num)
{
    const char *end = num + strlen(num) - 1;

    while (*num == *end) {
        ++num;
        --end;
    }

    return num > end;
}

//得到逆转的数并存入dest
void getReverse(char *dest, const char *src)
{
    const char *p = src + strlen(src) - 1;

    while (p >= src) {
        *dest++ = *p--;
    }
    *dest = '\0';
}

//字符转数字
int ctoi(char c)
{ return c - '0'; }

//数字转字符
char itoc(int num)
{ return num + '0'; }

//求left和right的和并存入left
void sum(char *left, const char *right)
{
    int x = 0; //进位
    int stack[1010];
    int top = 0;

    for (int i = strlen(right) - 1; i >= 0; --i) {
        x = x + ctoi(left[i]) + ctoi(right[i]);
        stack[top++] = x % 10;
        x /= 10;
    }
    //最后的进位
    if (x > 0) {
        stack[top++] = x;
    }
    while (top != 0) {
        *left++ = itoc(stack[--top]);
    }
    *left = '\0';
}

int main(void)
{
    char a[1010], b[1010];
    int count = 0;

    scanf("%s", a);
    while (!isPal(a) && count < 10) {
        getReverse(b, a);
        printf("%s + %s = ", a, b);
        sum(a, b);
        printf("%s\n", a);
        ++count;
    }
    if (isPal(a)) {
        printf("%s is a palindromic number.\n", a);
    }
    else {
        printf("Not found in 10 iterations.\n");
    }

    return 0;
}
```
