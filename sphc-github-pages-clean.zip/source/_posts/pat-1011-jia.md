---
title: PAT 1011.World Cup Betting
mathjax: true
toc: true
categories: 'PAT题解[甲级]'
tags:
  - PAT
abbrlink: 675c9ff7
date: 2018-02-01 14:37:59
---
## 题目
With the 2010 FIFA World Cup running, football fans the world over were becoming increasingly excited as the best players from the best teams doing battles for the World Cup trophy in South Africa. Similarly, football betting fans were putting their money where their mouths were, by laying all manner of World Cup bets.

Chinese Football Lottery provided a "Triple Winning" game. The rule of winning was simple: first select any three of the games. Then for each selected game, bet on one of the three possible results -- namely W for win, T for tie, and L for lose. There was an odd assigned to each result. The winner's odd would be the product of the three odds times 65%.

For example, 3 games' odds are given as the following:

 W    T    L
1.1  2.5  1.7
1.2  3.0  1.6
4.1  1.2  1.1

To obtain the maximum profit, one must buy W for the 3rd game, T for the 2nd game, and T for the 1st game. If each bet takes 2 yuans, then the maximum profit would be (4.1\*3.0\*2.5\*65%-1)\*2 = 37.98 yuans (accurate up to 2 decimal places).

**Input**

Each input file contains one test case. Each case contains the betting information of 3 games. Each game occupies a line with three distinct odds corresponding to W, T and L.

**Output**

For each test case, print in one line the best bet of each game, and the maximum profit accurate up to 2 decimal places. The characters and the number must be separated by one space.

**Sample Input**

1.1 2.5 1.7
1.2 3.0 1.6
4.1 1.2 1.1

**Sample Output**

T T W 37.98

## 我的解决方案
```cpp
#include <iostream>
#include <iomanip>

//解题思路:
//每次从三个数里找最大值,输出其标志,并累乘到收益中
//最后按公式计算结果

using namespace std;

const int SIZE = 3;

int main()
{
    double profit = 1;

    for (int i = 0; i < SIZE; ++i) {
        double w, t, l;

        cin >> w >> t >> l;
        if (w > t && w > l) {
            cout << "W" << " ";
            profit *= w;
        }
        else if (t > w && t > l) {
            cout << "T" << " ";
            profit *= t;
        }
        else if (l > w && l > t) {
            cout << "L" << " ";
            profit *= l;
        }
    }
    profit = (profit * 0.65 - 1) * 2;

    cout.setf(ios::fixed);
    cout.precision(2);
    cout << profit << endl;

    return 0;
}
```
