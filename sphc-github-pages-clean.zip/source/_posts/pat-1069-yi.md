---
title: PAT 1069.微博转发抽奖
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 4a9d89ff
date: 2018-01-01 23:12:33
---
## 题目
小明PAT考了满分，高兴之余决定发起微博转发抽奖活动，从转发的网友中按顺序每隔N个人就发出一个红包。请你编写程序帮助他确定中奖名单。

**输入格式：**

输入第一行给出三个正整数M（<= 1000）、N和S，分别是转发的总量、小明决定的中奖间隔、以及第一位中奖者的序号（编号从1开始）。随后M行，顺序给出转发微博的网友的昵称（不超过20个字符、不包含空格回车的非空字符串）。

注意：可能有人转发多次，但不能中奖多次。所以如果处于当前中奖位置的网友已经中过奖，则跳过他顺次取下一位。

**输出格式：**

按照输入的顺序输出中奖名单，每个昵称占一行。如果没有人中奖，则输出“Keep going...”。

**输入样例1：**

9 3 2
Imgonnawin!
PickMe
PickMeMeMeee
LookHere
Imgonnawin!
TryAgainAgain
TryAgainAgain
Imgonnawin!
TryAgainAgain

**输出样例1：**

PickMe
Imgonnawin!
TryAgainAgain

**输入样例2：**

2 3 5
Imgonnawin!
PickMe

**输出样例2：**

Keep going...

## 我的解决方案
```c
#include <stdio.h>
#include <string.h>

#define NPOS -1

int find(const char names[][21], int size, const char *str)
{
    for (int i = 0; i < size; ++i) {
        if (strcmp(names[i], str) == 0) {
            return i;
        }
    }

    return NPOS;
}

int main(void)
{
    int m, n;
    char names[1010][21]; //中奖网友
    int size = 0;
    int preOrder; //上一次中奖序号

    scanf("%d%d%d", &m, &n, &preOrder);
    //curOrder:当前序号
    for (int curOrder = 1; curOrder <= m; ++curOrder) {
        char name[21];

        scanf("%s", name);
        if (curOrder - n == preOrder || curOrder == preOrder) { 
            //读到下一个未出现的编号
            while (find(names, size, name) != NPOS && curOrder <= m) {
                scanf("%s", name);
                ++curOrder;
            }
            if (curOrder <= m) {
                printf("%s\n", name); 
                preOrder = curOrder;
                strcpy(names[size++], name); //保存中奖网友
            }
        }
    }
    if (size == 0) {
        printf("Keep going...\n");
    }

    return 0;
}
```
