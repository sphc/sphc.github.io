---
title: PAT 1057.数零壹
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 699425ea
date: 2017-12-31 20:01:51
---
## 题目
给定一串长度不超过10<sup>5</sup>的字符串，本题要求你将其中所有英文字母的序号（字母a-z对应序号1-26，不分大小写）相加，得到整数N，然后再分析一下N的二进制表示中有多少0、多少1。例如给定字符串“PAT (Basic)”，其字母序号之和为：16+1+20+2+1+19+9+3=71，而71的二进制是1000111，即有3个0、4个1。

**输入格式：**

输入在一行中给出长度不超过10<sup>5</sup>、以回车结束的字符串。

**输出格式：**

在一行中先后输出0的个数和1的个数，其间以空格分隔。

**输入样例：**

PAT (Basic)

**输出样例：**

3 4

## 我的解决方案
```c
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    char str[100010];
    int sum = 0, oneCount = 0, zeroCount = 0;

    fgets(str, 100010, stdin);
    for (int i = 0; i < strlen(str); ++i) {
        if (isalpha(str[i])) {
            sum += tolower(str[i]) - 'a' + 1;
        }
    }
    while (sum) {
        if (sum & 1) {
            ++oneCount;
        }
        else {
            ++zeroCount;
        }
        sum >>= 1;
    }
    printf("%d %d\n", zeroCount, oneCount);

    return 0;
}
```
