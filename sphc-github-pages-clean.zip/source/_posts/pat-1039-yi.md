---
title: PAT 1039.到底买不买
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 9e43aea2
date: 2017-12-22 22:32:19
---
## 题目
小红想买些珠子做一串自己喜欢的珠串。卖珠子的摊主有很多串五颜六色的珠串，但是不肯把任何一串拆散了卖。于是小红要你帮忙判断一下，某串珠子里是否包含了全部自己想要的珠子？如果是，那么告诉她有多少多余的珠子；如果不是，那么告诉她缺了多少珠子。

为方便起见，我们用[0-9]、[a-z]、[A-Z]范围内的字符来表示颜色。例如在图1中，第3串是小红想做的珠串；那么第1串可以买，因为包含了全部她想要的珠子，还多了8颗不需要的珠子；第2串不能买，因为没有黑色珠子，并且少了一颗红色的珠子。

<center>
<img src="https://t1.aixinxi.net/o_1cbj65uefubl1jnjgvj2m41ha0a.jpg-w.jpg" />
</center>
<center>图 1</center>

**输入格式：**

每个输入包含1个测试用例。每个测试用例分别在2行中先后给出摊主的珠串和小红想做的珠串，两串都不超过1000个珠子。

**输出格式：**

如果可以买，则在一行中输出“Yes”以及有多少多余的珠子；如果不可以买，则在一行中输出“No”以及缺了多少珠子。其间以1个空格分隔。

**输入样例1：**

ppRYYGrrYBR2258
YrR8RrY

**输出样例1：**

Yes 8

**输入样例2：**

ppRYYGrrYB225
YrR8RrY

**输出样例2：**

No 2

## 我的解决方案
```c
#include <stdio.h>

#define SIZE 129

int count[SIZE] = {0}; //下标为某一字符，保存摊主该字符的个数

int main(void)
{
    int c;
    int left = 0; //多余的
    int lack = 0; //缺少的

    //输入摊主珠串，并为各字符计数
    while ((c = getchar()) != EOF && c != '\n') {
        ++count[c];
    }
    //输入小红珠串，并从字符总数中将其减去
    while ((c = getchar()) != EOF && c != '\n') {
        --count[c];
    }
    //统计缺少的个数，多余的个数
    for (int i = 0; i < SIZE; ++i) {
        if (count[i] < 0) {
            lack += -count[i];
        }
        else if (count[i] > 0) {
            left += count[i];
        }
    }
    if (lack > 0) {
        printf("No %d\n", lack);
    }
    else {
        printf("Yes %d\n", left);
    }

    return 0;
}
```
