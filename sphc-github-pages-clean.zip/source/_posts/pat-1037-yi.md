---
title: PAT 1037.在霍格沃茨找零钱
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: b6f538fd
date: 2017-12-19 23:43:53
---
## 题目
如果你是哈利·波特迷，你会知道魔法世界有它自己的货币系统 —— 就如海格告诉哈利的：“十七个银西可(Sickle)兑一个加隆(Galleon)，二十九个纳特(Knut)兑一个西可，很容易。”现在，给定哈利应付的价钱P和他实付的钱A，你的任务是写一个程序来计算他应该被找的零钱。

输入格式：

输入在1行中分别给出P和A，格式为“Galleon.Sickle.Knut”，其间用1个空格分隔。这里Galleon是[0, 10<sup>7</sup>]区间内的整数，Sickle是[0, 17)区间内的整数，Knut是[0, 29)区间内的整数。

**输出格式：**

在一行中用与输入同样的格式输出哈利应该被找的零钱。如果他没带够钱，那么输出的应该是负数。

**输入样例1：**

10.16.27 14.1.28

**输出样例1：**

3.2.1

**输入样例2：**

14.1.28 10.16.27

**输出样例2：**

-3.2.1

## 我的解决方案
```c
#include <stdio.h>
#include <stdbool.h>

typedef struct {
    int galleon;
    int sickle;
    int knut;
} Money;

void inputMoney(Money *money)
{ scanf("%d.%d.%d", &money->galleon, &money->sickle, &money->knut); }

void printMoney(const Money *money)
{ printf("%d.%d.%d", money->galleon, money->sickle, money->knut); }

//left大于等于right
bool isBiggerOrEqual(const Money *left, const Money *right)
{ 
     return (left->galleon > right->galleon) ||
            (left->galleon == right->galleon && left->sickle > right->sickle) ||
            (left->galleon == right->galleon && left->sickle == right->sickle && 
             left->knut >= right->knut); 
}

//减法
void subtract(const Money *left, const Money *right, Money *result)
{
    if (isBiggerOrEqual(left, right)) {
        result->galleon = left->galleon - right->galleon;
        result->sickle = left->sickle - right->sickle;
        result->knut = left->knut - right->knut;
        //如果小于0，则表明需要借位
        if (result->knut < 0) {
            result->knut += 29;
            --result->sickle;
        }
        if (result->sickle < 0) {
            result->sickle += 17;
            --result->galleon;
        }
    }
    else { //此时表明为负数
        subtract(right, left, result);
        result->galleon = -result->galleon;
    }
}

int main(void)
{
    Money p, a, c;

    inputMoney(&p);
    inputMoney(&a);
    subtract(&a, &p, &c);
    printMoney(&c);
    putchar('\n');

    return 0;
}
```
