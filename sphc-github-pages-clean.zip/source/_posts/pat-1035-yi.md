---
title: PAT 1035.插入与归并
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: a839cf99
date: 2019-04-26 16:45:16
---
## 题目
根据维基百科的定义：

插入排序是迭代算法，逐一获得输入数据，逐步产生有序的输出序列。每步迭代中，算法从输入序列中取出一元素，将之插入有序序列中正确的位置。如此迭代直到全部元素有序。

归并排序进行如下迭代操作：首先将原始序列看成 N 个只包含 1 个元素的有序子序列，然后每次迭代归并两个相邻的有序子序列，直到最后只剩下 1 个有序的序列。

现给定原始序列和由某排序算法产生的中间序列，请你判断该算法究竟是哪种排序算法？

**输入格式：**

输入在第一行给出正整数 N (≤100)；随后一行给出原始序列的 N 个整数；最后一行给出由某排序算法产生的中间序列。这里假设排序的目标序列是升序。数字间以空格分隔。

**输出格式：**

首先在第 1 行中输出Insertion Sort表示插入排序、或Merge Sort表示归并排序；然后在第 2 行中输出用该排序算法再迭代一轮的结果序列。题目保证每组测试的结果是唯一的。数字间以空格分隔，且行首尾不得有多余空格。

**输入样例 1：**

10
3 1 2 8 7 5 9 4 6 0
1 2 3 7 8 5 9 4 6 0

**输出样例 1：**

Insertion Sort
1 2 3 5 7 8 9 4 6 0

**输入样例 2：**

10
3 1 2 8 7 5 9 4 0 6
1 3 2 8 5 7 4 9 0 6

**输出样例 2：**

Merge Sort
1 2 3 8 4 5 7 9 0 6

## 我的解决方案
```c
#include <stdio.h>
#include <stdbool.h>

#define SIZE 10000

bool equal(const int *left, const int *right, int size)
{
    for (int i = 0; i < size; ++i) {
        if (left[i] != right[i]) {
            return false;
        }
    }

    return true;
}

void printArr(const int *a, int size)
{
    for (int i = 0; i < size; ++i) {
        if (i) {
            printf(" ");
        }
        printf("%d", a[i]);
    }
    printf("\n");
}

bool insertSort(int *a, int size, const int *sequence)
{
    bool success = false;

    for (int i = 1; i < size; ++i) {
        int j = i;
        int tmp = a[i];

        for (; j > 0 && a[j - 1] > tmp; --j) {
            a[j] = a[j - 1];
        }
        a[j] = tmp;
        if (success) {
            printArr(a, size);
            break;
        }
        if (equal(a, sequence, size)) {
            printf("Insertion Sort\n");
            success = true;
        }
    }

    return success;
}

void merge(int *a, int *tmp, int left, int leftEnd, int rightEnd)
{
    int right = leftEnd;
    int tmpPos = left;
    int count = rightEnd - left;

    while (left < leftEnd && right < rightEnd) {
        tmp[tmpPos++] = a[right] < a[left] ? a[right++] : a[left++];
    }
    while (left < leftEnd) {
        tmp[tmpPos++] = a[left++];
    }
    while (right < rightEnd) {
        tmp[tmpPos++] = a[right++];
    }

    while (count--) {
        --rightEnd;
        a[rightEnd] = tmp[rightEnd];
    }
}

void mergeSort(int *a, int size, const int *sequence)
{
    int tmp[SIZE];
    bool success = false;

    for (int step = 1; step < size; step *= 2) {
        int left, mid, right;
        for (left = 0; left < size - step; left = right) {
            mid = left + step; 
            right = (mid + step > size ? size : mid + step);
            merge(a, tmp, left, mid, right);
        }
        if (success) {
            printArr(a, size);
            return;
        }
        if (equal(a, sequence, size)) {
            printf("Merge Sort\n");
            success = true;
        }
    }
}

int main(void)
{
    int n;
    int a[SIZE], b[SIZE];
    int sequence[SIZE];
    int tmp[SIZE];

    scanf("%d", &n);
    for (int i = 0; i < n; ++i) {
        scanf("%d", a + i);
        b[i] = a[i];
    }
    for (int i = 0; i < n; ++i) {
        scanf("%d", sequence + i);
    }
    if (!insertSort(a, n, sequence)) {
        mergeSort(b, n, sequence);
    }

    return 0;
}
```
