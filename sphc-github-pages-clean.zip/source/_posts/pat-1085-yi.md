---
title: PAT 1085.PAT单位排行
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: c6850a59
date: 2018-03-25 16:20:40
---

## 题目

每次 PAT 考试结束后，考试中心都会发布一个考生单位排行榜。本题就请你实现这个功能。 

**输入格式：**

输入第一行给出一个正整数N（<=10<sup>5</sup>），即考生人数。随后N行，每行按下列格式给出一个考生的信息： 

准考证号 得分 学校 

其中“准考证号”是由6个字符组成的字符串，其首字母表示考试的级别：“B”代表乙级，“A”代表甲级，“T”代表顶级；“得分”是 [0,100] 区间内的整数；“学校”是由不超过6个英文字母组成的单位码（大小写无关）。注意：题目保证每个考生的准考证号是不同的。 

**输出格式：**

首先在一行中输出单位个数。随后按以下格式非降序输出单位的排行榜： 

排名 学校 加权总分 考生人数 

其中“排名”是该单位的排名（从1开始）；“学校”是全部按小写字母输出的单位码；“加权总分”定义为“乙级总分/1.5 + 甲级总分 + 顶级总分*1.5”的整数部分；“考生人数”是该属于单位的考生的总人数。 

学校首先按加权总分排行。如有并列，则应对应相同的排名，并按考生人数升序输出。如果仍然并列，则按单位码的字典序输出。 

**输入样例：**

10
A57908 85 Au
B57908 54 LanX
A37487 60 au
T28374 67 CMU
T32486 24 hypu
A66734 92 cmu
B76378 71 AU
A47780 45 lanx
A72809 100 pku
A03274 45 hypu

**输出样例：**

5
1 cmu 192 2
1 au 192 3
3 pku 100 1
4 hypu 81 2
4 lanx 81 2

## 我的解决方案
```cpp
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

//解题思路:
//在输入时多次使用查找会导致运行超时,
//我这里先将输入项保存到一个数组中,
//然后进行排序,这样学校相同的项将会位于相邻位置,
//第二遍遍历的时候将其成绩汇总并计算加权总分,
//再保存到结果数组

#define SIZE 100010

typedef struct Grade {
    char school[10];//学校
    int grade;      //加权总分
    int count;      //人数
} Grade;

typedef struct InputInfo {
    char id[10];    //准考证号
    int grade;      //得分
    char school[10];//学校
} InputInfo;

int cmp_in(const void *left, const void *right)
{ return strcmp(((const InputInfo *)left)->school, 
                ((const InputInfo *)right)->school); }

int cmp_g(const void *left, const void *right)
{ 
    const Grade *first = left, *second = right;

    if (first->grade != second->grade) {
        return second->grade - first->grade; 
    }
    if (first->count != second->count) {
        return first->count - second->count; 
    }
    return strcmp(first->school, second->school);
}

void initGrade(Grade *grade)
{ grade->count = 0; }

//将字符串s转为小写
void Lower(char *s)
{ 
    while (*s) {
        *s = tolower(*s);
        ++s;
    }
}

int main(void)
{
    int n, rank = 1;    //rank:排名
    Grade grades[SIZE]; //保存结果
    InputInfo in[SIZE]; //保存输入项
    int size = 0;

    scanf("%d", &n);
    for (int i = 0; i < n; ++i) {
        scanf("%s%d%s", in[i].id, &in[i].grade, in[i].school);
        Lower(in[i].school);
    }
    qsort(in, n, sizeof(InputInfo), cmp_in);

    for (int i = 0; i < n; ) {
        int j;
        int basic = 0;      //乙级
        int advance = 0;    //甲级
        int top = 0;        //顶级

        initGrade(grades + size);
        strcpy(grades[size].school, in[i].school);
        //找出学校相同的输入项,并将成绩汇总
        for (j = i; j < n && strcmp(in[j].school, in[i].school) == 0; ++j) {
            ++grades[size].count;
            switch(in[j].id[0]) {
                case 'A' : advance += in[j].grade; break;
                case 'B' : basic += in[j].grade; break;
                case 'T' : top += in[j].grade; break;
            }
        }
        //计算加权总分
        grades[size++].grade = basic / 1.5 + advance + top * 1.5; 
        i = j;
    }
    qsort(grades, size, sizeof(Grade), cmp_g);

    printf("%d\n", size);
    for (int i = 0; i < size; ++i) {
        //若和上一名成绩不同,则排名为下标加一
        if (i && grades[i].grade != grades[i - 1].grade) {
            rank = i + 1;
        }
        printf("%d %s %d %d\n", rank, grades[i].school, grades[i].grade, grades[i].count);
    }

    return 0;
}
```
