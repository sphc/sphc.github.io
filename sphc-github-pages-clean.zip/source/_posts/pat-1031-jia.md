---
title: PAT 1031.Hello World for U
mathjax: true
toc: true
categories: 'PAT题解[甲级]'
tags:
  - PAT
abbrlink: 60d364b5
date: 2018-02-08 23:02:28
---
## 题目
Given any string of N (>=5) characters, you are asked to form the characters into the shape of U. For example, "helloworld" can be printed as:

<pre>
h  d
e  l
l  r
lowo
</pre>

That is, the characters must be printed in the original order, starting top-down from the left vertical line with n<sub>1</sub> characters, then left to right along the bottom line with n<sub>2</sub> characters, and finally bottom-up along the vertical line with n<sub>3</sub> characters. And more, we would like U to be as squared as possible -- that is, it must be satisfied that n<sub>1</sub> = n<sub>3</sub> = max { k| k <= n<sub>2</sub> for all 3 <= n<sub>2</sub> <= N } with n<sub>1</sub> + n<sub>2</sub> + n<sub>3</sub> - 2 = N.

**Input Specification:**

Each input file contains one test case. Each case contains one string with no less than 5 and no more than 80 characters in a line. The string contains no white space.

**Output Specification:**

For each test case, print the input string in the shape of U as specified in the description.

**Sample Input:**

helloworld!

**Sample Output:**

<pre>
h   !
e   d
l   l
lowor
</pre>

## 我的解决方案
```cpp
#include <iostream>
#include <string>

//解题思路:
//1.计算n1,n2:通过循环枚举找k的最大取值即n1,同时保存n2的值
//2.将字符填入二维数组,U型之外的部分以空格填充

using namespace std;

//以U型打印s
void printU(const string &s)
{
    int n1 = 0, n2, size = s.size();
    char tmp[100][100];

    //计算n1,n2
    int t = size;
    while (t >= 3) {
        int k = t;
        while (k) {
            if (2 * k + t - 2 == size) {
                if (n1 < k) {
                    n1 = k;
                    n2 = t;
                }
                break;
            }
            --k;
        }
        --t;
    }

    //以空格填充
    for (int i = 0; i < n1; ++i) {
        for (int j = 0; j < n2; ++j) {
            tmp[i][j] = ' ';
        }
    }

    //字符填入矩阵
    int x = 0, y = 0, z = 0;
    for (int i = 0; i < n1 - 1; ++i) {
        tmp[x++][y] = s[z++];
    }
    for (int i = 0; i < n2; ++i) {
        tmp[x][y++] = s[z++];
    }
    --y;
    for (int i = 0; i < n1; ++i) {
        tmp[--x][y] = s[z++];
    }

    //打印
    for (int i = 0; i < n1; ++i) {
        for (int j = 0; j < n2; ++j) {
            cout << tmp[i][j];
        }
        cout << endl;
    }
}

int main()
{
    string s;

    cin >> s;
    printU(s);

    return 0;
}
```
