---
title: PAT 1032.挖掘机技术哪家强
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: '30918081'
date: 2017-12-18 21:13:52
---
## 题目
为了用事实说明挖掘机技术到底哪家强，PAT组织了一场挖掘机技能大赛。现请你根据比赛结果统计出技术最强的那个学校。

**输入格式：**

输入在第1行给出不超过10<sup>5</sup>的正整数N，即参赛人数。随后N行，每行给出一位参赛者的信息和成绩，包括其所代表的学校的编号（从1开始连续编号）、及其比赛成绩（百分制），中间以空格分隔。

**输出格式：**

在一行中给出总得分最高的学校的编号、及其总分，中间以空格分隔。题目保证答案唯一，没有并列。

**输入样例：**

6
3 65
2 80
1 100
2 70
3 40
3 0

**输出样例：**

2 150

## 我的解决方案
```c
#include <stdio.h>
#include <limits.h>

int a[100010] = {0};

int main(void)
{
    int n;
    int num, grade;

    scanf("%d", &n);
    for (int i = 0; i < n; ++i) {
        scanf("%d%d", &num, &grade);
        a[num] += grade;
    }
    grade = INT_MIN;
    for (int i = 1; i <= n; ++i) {
        //找出得分最高者,保存在grade和num中
        if (a[i] > grade) {
            grade = a[i];
            num = i;
        }
    }
    printf("%d %d\n", num, grade); 

    return 0;
}
```
