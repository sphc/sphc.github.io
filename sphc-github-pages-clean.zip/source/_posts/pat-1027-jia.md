---
title: PAT 1027.Colors in Mars
mathjax: true
toc: true
categories: 'PAT题解[甲级]'
tags:
  - PAT
abbrlink: 28927a09
date: 2018-02-08 23:00:52
---
## 题目
People in Mars represent the colors in their computers in a similar way as the Earth people. That is, a color is represented by a 6-digit number, where the first 2 digits are for Red, the middle 2 digits for Green, and the last 2 digits for Blue. The only difference is that they use radix 13 (0-9 and A-C) instead of 16. Now given a color in three decimal numbers (each between 0 and 168), you are supposed to output their Mars RGB values.

**Input**

Each input file contains one test case which occupies a line containing the three decimal color values.

**Output**

For each test case you should output the Mars RGB value in the following format: first output "#", then followed by a 6-digit number where all the English characters must be upper-cased. If a single color is only 1-digit long, you must print a "0" to the left.

**Sample Input**

15 43 71

**Sample Output**

\#123456

## 我的解决方案
```cpp
#include <iostream>
#include <string>

//解题思路:
//比较简单,只需将每个数转换为13进制

using namespace std;

//转换num为13进制
string trans(int num)
{
    string result;

    while (num) {
        char digit;
        if (num % 13 > 9) {
            digit = num % 13 - 10 + 'A';
        }
        else {
            digit = num % 13 + '0';
        }
        result = digit + result;
        num /= 13;
    }
    //补0,用while是考虑num为0的情况
    while (result.size() < 2) {
        result = "0" + result;
    }

    return result;
}

int main()
{
    int first, second, third;

    cin >> first >> second >> third;
    cout << "#" << trans(first) << trans(second) << trans(third) << endl;

    return 0;
}
```
