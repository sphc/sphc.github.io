---
title: PAT 1054.求平均值
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 3540c576
date: 2018-01-30 21:26:32
---
## 题目
本题的基本要求非常简单：给定N个实数，计算它们的平均值。但复杂的是有些输入数据可能是非法的。一个“合法”的输入是[-1000，1000]区间内的实数，并且最多精确到小数点后2位。当你计算平均值的时候，不能把那些非法的数据算在内。

**输入格式：**

输入第一行给出正整数N（<=100）。随后一行给出N个实数，数字间以一个空格分隔。

**输出格式：**

对每个非法输入，在一行中输出“ERROR: X is not a legal number”，其中X是输入。最后在一行中输出结果：“The average of K numbers is Y”，其中K是合法输入的个数，Y是它们的平均值，精确到小数点后2位。如果平均值无法计算，则用“Undefined”替换Y。如果K为1，则输出“The average of 1 number is Y”。

**输入样例1：**

7
5 -3.2 aaa 9999 2.3.4 7.123 2.35

**输出样例1：**

ERROR: aaa is not a legal number
ERROR: 9999 is not a legal number
ERROR: 2.3.4 is not a legal number
ERROR: 7.123 is not a legal number
The average of 3 numbers is 1.38

**输入样例2：**

2
aaa -9999

**输出样例2：**

ERROR: aaa is not a legal number
ERROR: -9999 is not a legal number
The average of 0 numbers is Undefined

## 我的解决方案
```c
#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>

#define SIZE 100

//若字符串s合法则将其转换为double并赋予*num,返回true,否则返回false
bool sToDouble(const char *s, double *num)
{
    double intPart = 0, decimalPart = 0;
    int i = 0, j;

    //点出现在首部,非法
    if (s[i] == '.') {
        return false;
    }
    //第一个字符为负,跳过
    if (s[i] == '-') {
        ++i;
    }

    //累加整数部分
    while (s[i] && s[i] != '.') {
        if (!isdigit(s[i])) {
            return false;
        }
        intPart = intPart * 10 + s[i++] - '0';
    }

    //将j置于小数点后的位置
    j = s[i] == '.' ? i + 1 : i;

    //考虑末尾带点非法会导致测试点过不去
    /*
    if (j == i + 1 && s[j] == '\0') {
        return false;
    }
    */

    //累加小数部分
    while (s[j]) {
        //j - i > 2代表精度超过2
        if (!isdigit(s[j]) || j - i > 2) {
            return false;
        }
        decimalPart = decimalPart * 10 + s[j++] - '0';
    }

    //将小数点置回原位
    while (j-- > i + 1) {
        decimalPart /= 10;
    }

    intPart += decimalPart;

    //范围之外,非法
    if (intPart < -1000 || intPart > 1000) {
        return false;
    }

    *num = intPart;
    //补上负号
    if (s[0] == '-') {
        *num *= -1;
    }

    return true;
}

int main(void)
{
    int n;
    char s[SIZE];
    double num, sum = 0;
    int count = 0; //合法数的个数

    scanf("%d", &n);
    for (int i = 0; i < n; ++i) {
        scanf("%s", s);
        if (sToDouble(s, &num)) {
            sum += num;
            ++count;
        }
        else {
            printf("ERROR: %s is not a legal number\n", s);
        }
    }

    if (count) {
        printf("The average of %d %s is %.2f\n", count, 
                count == 1 ? "number" : "numbers", sum / count);
    }
    else {
        printf("The average of 0 numbers is Undefined\n");
    }

    return 0;
}
```
