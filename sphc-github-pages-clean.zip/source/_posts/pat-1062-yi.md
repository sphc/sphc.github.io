---
title: PAT 1062.最简分数
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 78f832de
date: 2018-01-29 22:39:22
---
## 题目
一个分数一般写成两个整数相除的形式：N/M，其中M不为0。最简分数是指分子和分母没有公约数的分数表示形式。

现给定两个不相等的正分数 N<sub>1</sub>/M<sub>1</sub> 和 N<sub>2</sub>/M<sub>2</sub>，要求你按从小到大的顺序列出它们之间分母为K的最简分数。

**输入格式：**

输入在一行中按N/M的格式给出两个正分数，随后是一个正整数分母K，其间以空格分隔。题目保证给出的所有整数都不超过1000。

**输出格式：**

在一行中按N/M的格式列出两个给定分数之间分母为K的所有最简分数，按从小到大的顺序，其间以1个空格分隔。行首尾不得有多余空格。题目保证至少有1个输出。

**输入样例：**

7/18 13/20 12

**输出样例：**

5/12 7/12

## 我的解决方案
```c
#include <stdio.h>
#include <stdbool.h>

typedef struct {
    int x; //分子
    int y; //分母
} Fraction;

//最大公因数
int gcd(int m, int n)
{ return n ? gcd(n, m % n) : m; }

//输入分数
void inputFraction(Fraction *fraction)
{ scanf("%d/%d", &fraction->x, &fraction->y); }

//打印分数
void printFraction(const Fraction *fraction)
{ printf("%d/%d", fraction->x, fraction->y); }

//交换两个分数
void swap(Fraction *left, Fraction *right)
{
    Fraction tmp = *left;
    *left = *right;
    *right = tmp;
}

//设置分数的值
void setFraction(Fraction *fraction, int x, int y)
{
    fraction->x = x;
    fraction->y = y;
}

//left < right则返回true
bool isLess(const Fraction *left, const Fraction *right)
{ return left->x * right->y < right->x * left->y; }

//left == right则返回true
bool isEqual(const Fraction *left, const Fraction *right)
{ return left->x * right->y == right->x * left->y; }

int main(void)
{
    int k;
    bool first = true;
    Fraction a, b;

    inputFraction(&a);
    inputFraction(&b);
    scanf("%d", &k);

    if (!isLess(&a, &b)) {
        swap(&a, &b);
    }

    for (int i = 1; i < k; ++i) {
        Fraction c;

        setFraction(&c, i, k);
        //跳过小于等于a的分数
        if (isLess(&c, &a) || isEqual(&c, &a)) {
            continue;
        }
        //大于等于b则跳出
        if (!isLess(&c, &b)) {
            break;
        }

        //分子分母没有公约数时打印
        if (gcd(i, k) == 1) {
            if (!first) {
                printf(" ");
            }
            printFraction(&c);
            first = false;
        }
    }
    printf("\n");

    return 0;
}
```
