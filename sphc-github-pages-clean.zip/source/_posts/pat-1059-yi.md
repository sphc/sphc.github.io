---
title: PAT 1059.C语言竞赛
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 87c88a8d
date: 2017-12-31 20:04:47
---
## 题目
C语言竞赛是浙江大学计算机学院主持的一个欢乐的竞赛。既然竞赛主旨是为了好玩，颁奖规则也就制定得很滑稽：

0. 冠军将赢得一份“神秘大奖”（比如很巨大的一本学生研究论文集……）。
1. 排名为素数的学生将赢得最好的奖品 —— 小黄人玩偶！
2. 其他人将得到巧克力。

给定比赛的最终排名以及一系列参赛者的ID，你要给出这些参赛者应该获得的奖品。

**输入格式：**

输入第一行给出一个正整数N（<=10000），是参赛者人数。随后N行给出最终排名，每行按排名顺序给出一位参赛者的ID（4位数字组成）。接下来给出一个正整数K以及K个需要查询的ID。

**输出格式：**

对每个要查询的ID，在一行中输出“ID: 奖品”，其中奖品或者是“Mystery Award”（神秘大奖）、或者是“Minion”（小黄人）、或者是“Chocolate”（巧克力）。如果所查ID根本不在排名里，打印“Are you kidding?”（耍我呢？）。如果该ID已经查过了（即奖品已经领过了），打印“ID: Checked”（不能多吃多占）。

**输入样例：**

6
1111
6666
8888
1234
5555
0001
6
8888
0001
1111
2222
8888
2222

**输出样例：**

8888: Minion
0001: Chocolate
1111: Mystery Award
2222: Are you kidding?
8888: Checked
2222: Are you kidding?

## 我的解决方案
```c
#include <stdio.h>
#include <stdbool.h>

//表示未找到
#define NPOS -1 
//已找过
#define VISITED -2222

bool isPrime(int num)
{
    for (int i = 2; i * i <= num; ++i) {
        if (num % i == 0) {
            return false;
        }
    }

    return true;
}

int find(const int *arr, int size, int value)
{
    static int visited[10010] = {0};

    for (int i = 0; i < size; ++i) {
        if (arr[i] == value) {
            if (visited[i]) {
                return VISITED;
            }
            else {
                visited[i] = 1;

                return i;
            }
        }
    }

    return NPOS;
}

int main(void)
{
    int final[10010] = {0}; //下标为最终排名减一，值为ID
    int n, k;

    scanf("%d", &n);
    for (int i = 0; i < n; ++i) {
        scanf("%d", final + i);
    }
    scanf("%d", &k);
    while (k--) {
        int id;
        int rank; //排名

        scanf("%d", &id);
        printf("%.4d: ", id);
        rank = find(final, n, id);
        switch (rank) {
            case 0 : printf("Mystery Award\n"); break;
            case NPOS : printf("Are you kidding?\n"); break;
            case VISITED : printf("Checked\n"); break;
            //因为数组索引从0开始，所以这里要加1
            default: printf("%s\n", isPrime(rank + 1) ? "Minion" : "Chocolate"); break;
        }
    }

    return 0;
}
```
