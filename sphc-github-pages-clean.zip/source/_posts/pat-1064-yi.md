---
title: PAT 1064.朋友数
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 20a63d55
date: 2017-12-30 20:16:11
---
## 题目
如果两个整数各位数字的和是一样的，则被称为是“朋友数”，而那个公共的和就是它们的“朋友证号”。例如123和51就是朋友数，因为1+2+3 = 5+1 = 6，而6就是它们的朋友证号。给定一些整数，要求你统计一下它们中有多少个不同的朋友证号。注意：我们默认一个整数自己是自己的朋友。

**输入格式：**

输入第一行给出正整数N。随后一行给出N个正整数，数字间以空格分隔。题目保证所有数字小于10<sup>4</sup>。

**输出格式：**

首先第一行输出给定数字中不同的朋友证号的个数；随后一行按递增顺序输出这些朋友证号，数字间隔一个空格，且行末不得有多余空格。

**输入样例：**

8
123 899 51 998 27 33 36 12

**输出样例：**

4
3 6 9 26

## 我的解决方案
```c
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

//num是否已出现过
bool isExisted(const int *arr, int index, int num)
{
    for (int i = 0; i < index; ++i) {
        if (arr[i] == num) {
            return true;
        }
    }

    return false;
}

//获取朋友证号
int friend(int num)
{
    int sum = 0;

    while (num) {
        sum += num % 10;
        num /= 10;
    }

    return sum;
}

int cmp(const void *left, const void *right)
{ return *(int *)left - *(int *)right; }

int main(void)
{
    int n;
    int result[10010];
    int size = 0;

    scanf("%d", &n);
    for (int i = 0; i < n; ++i) {
        int num;

        scanf("%d", &num);
        num = friend(num);
        if (!isExisted(result, size, num)) {
            result[size++] = num;
        }
    }

    qsort(result, size, sizeof(int), cmp);
    printf("%d\n", size);
    for (int i = 0; i < size; ++i) {
        if (i) {
            putchar(' ');
        }
        printf("%d", result[i]);
    }
    putchar('\n');

    return 0;
}
```
