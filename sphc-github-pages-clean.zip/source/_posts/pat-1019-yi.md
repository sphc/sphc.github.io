---
title: PAT 1019.数字黑洞
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: b1bb4296
date: 2017-12-13 12:57:07
---
## 题目
给定任一个各位数字不完全相同的4位正整数，如果我们先把4个数字按非递增排序，再按非递减排序，然后用第1个数字减第2个数字，将得到一个新的数字。一直重复这样做，我们很快会停在有“数字黑洞”之称的6174，这个神奇的数字也叫Kaprekar常数。

例如，我们从6767开始，将得到

7766 - 6677 = 1089
9810 - 0189 = 9621
9621 - 1269 = 8352
8532 - 2358 = 6174
7641 - 1467 = 6174
... ...

现给定任意4位正整数，请编写程序演示到达黑洞的过程。

**输入格式：**

输入给出一个(0, 10000)区间内的正整数N。

**输出格式：**

如果N的4位数字全相等，则在一行内输出“N - N = 0000”；否则将计算的每一步在一行内输出，直到6174作为差出现，输出格式见样例。注意每个数字按4位数格式输出。

**输入样例1：**

6767

**输出样例1：**

7766 - 6677 = 1089
9810 - 0189 = 9621
9621 - 1269 = 8352
8532 - 2358 = 6174

**输入样例2：**

2222

**输出样例2：**

2222 - 2222 = 0000

## 我的解决方案
```c
#include <stdio.h>
#include <string.h>

#define SIZE 10

//将n各位数放到数组a中，这样便于产生非递减和非递增的数
void trans(int *nums, int n)
{
    int size = 4;

    while (n) {
        ++nums[n % 10];
        n /= 10;
        --size;
    }

    //如果size大于0，说明数字前导的0未算进去
    if (size > 0) {
        nums[0] += size;
    }
}

//根据nums产生非递增的数
int generateFirst(int *nums, int size)
{
    int result = 0;

    for (int i = size - 1; i >= 0; --i) {
        for (int j = 0; j < nums[i]; ++j) {
            result = result * 10 + i;
        }
    }

    return result;
}

//根据nums产生非递减的数
int generateSecond(int *nums, int size)
{
    int result = 0;

    for (int i = 0; i < size; ++i) {
        for (int j = 0; j < nums[i]; ++j) {
            result = result * 10 + i;
        }
    }

    return result;
}

int main(void)
{
    int n;
    int x, y; //x:非递增的数; y:非递减的数
    int nums[SIZE] = {0}; //存放某一数中的各位数字及个数

    scanf("%d", &n);
    do {
        trans(nums, n);
        x = generateFirst(nums, SIZE);
        y = generateSecond(nums, SIZE);
        memset(nums, 0, sizeof(int) * SIZE); //清零
        n = x - y;
        printf("%.4d - %.4d = %.4d\n", x, y, n); 
    } while (n != 6174 && n != 0);

    return 0;
}
```
