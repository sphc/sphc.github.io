---
title: PAT 1069.The Black Hole of Numbers
mathjax: true
toc: true
categories: 'PAT题解[甲级]'
tags:
  - PAT
abbrlink: 51404ee9
date: 2018-02-13 12:52:51
---
## 题目
For any 4-digit integer except the ones with all the digits being the same, if we sort the digits in non-increasing order first, and then in non-decreasing order, a new number can be obtained by taking the second number from the first one. Repeat in this manner we will soon end up at the number 6174 -- the "black hole" of 4-digit numbers. This number is named Kaprekar Constant.

For example, start from 6767, we'll get:

7766 - 6677 = 1089
9810 - 0189 = 9621
9621 - 1269 = 8352
8532 - 2358 = 6174
7641 - 1467 = 6174
... ...

Given any 4-digit number, you are supposed to illustrate the way it gets into the black hole.

**Input Specification:**

Each input file contains one test case which gives a positive integer N in the range (0, 10000).

**Output Specification:**

If all the 4 digits of N are the same, print in one line the equation "N - N = 0000". Else print each step of calculation in a line until 6174 comes out as the difference. All the numbers must be printed as 4-digit numbers.

**Sample Input 1:**

6767

**Sample Output 1:**

7766 - 6677 = 1089
9810 - 0189 = 9621
9621 - 1269 = 8352
8532 - 2358 = 6174

**Sample Input 2:**

2222

**Sample Output 2:**

2222 - 2222 = 0000

## 我的解决方案
```cpp
#include <iostream>
#include <algorithm>
#include <string>

//解题思路:
//string保存数字,sort排序,用stod转换后计算

using namespace std;

//转为字符串,占4位,其余位补0
string toString(int num)
{
    string s(4, '0');
    string::reverse_iterator i = s.rbegin();

    while (num && i != s.rend()) {
        *i++ = num % 10 + '0';
        num /= 10;
    }
    
    return s;
}

int main()
{
    string num;
    int result = -1;

    //这样写,使输入0时得到0000而不是0
    int x; 
    cin >> x;
    num = toString(x);

    while (result != 0 && result != 6174) {
        sort(begin(num), end(num), 
                [] (const char &left, const char &right) { return left > right; }
        );
        result = stod(num);
        cout << num << " - ";
        sort(begin(num), end(num));
        result -= stod(num);
        cout << num << " = "; 
        num = toString(result);
        cout << num << endl;
    }

    return 0;
}
```
