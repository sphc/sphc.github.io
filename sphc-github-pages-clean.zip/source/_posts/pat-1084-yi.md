---
title: PAT 1084.外观数列
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 6623cc06
date: 2018-03-25 16:20:32
---

## 题目

外观数列是指具有以下特点的整数序列：

d, d1, d111, d113, d11231, d112213111, ...

它从不等于 1 的数字 d 开始，序列的第 n+1 项是对第 n 项的描述。比如第 2 项表示第 1 项有 1 个 d，所以就是 d1；第 2 项是 1 个 d（对应 d1）和 1 个 1（对应 11），所以第 3 项就是 d111。又比如第 4 项是 d113，其描述就是 1 个 d，2 个 1，1 个 3，所以下一项就是 d11231。当然这个定义对 d = 1 也成立。本题要求你推算任意给定数字 d 的外观数列的第 N 项。 

**输入格式：**

输入第一行给出[0,9]范围内的一个整数 d、以及一个正整数 N（<=40），用空格分隔。 

**输出格式：**

在一行中给出数字 d 的外观数列的第 N 项。 

**输入样例：**

1 8

**输出样例：**

1123123111

## 我的解决方案
```cpp
#include <stdio.h>

#define SIZE 100000

int main(void)
{
    int n;
    int a[SIZE], result[SIZE]; //这里使用两个数组,以避免值被覆盖造成的错误
    int size = 0;

    scanf("%d%d", result + size++, &n);
    while (--n) {
        int tmp = 0;
        for (int i = 0; i < size; ++i) {
            int count = 1;

            a[tmp++] = result[i];
            //计算连续的相同值的个数
            while (i + 1 < size && result[i] == result[i + 1]) {
                ++count;
                ++i;
            }
            a[tmp++] = count;
        }
        //结果拷贝回去
        for (int i = 0; i < tmp; ++i) {
            result[i] = a[i];
        }
        size = tmp;
    }

    //打印结果
    for (int i = 0; i < size; ++i) {
        printf("%d", result[i]);
    }
    printf("\n");

    return 0;
}
```
