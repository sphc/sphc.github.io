---
title: PAT 1078.字符串压缩与解压
mathjax: true
toc: true
categories: 'PAT题解[乙级]'
tags:
  - PAT
abbrlink: 1f61a560
date: 2017-12-30 20:23:49
---
## 题目
文本压缩有很多种方法，这里我们只考虑最简单的一种：把由相同字符组成的一个连续的片段用这个字符和片段中含有这个字符的个数来表示。例如 ccccc 就用 5c 来表示。如果字符没有重复，就原样输出。例如 aba 压缩后仍然是 aba。

解压方法就是反过来，把形如 5c 这样的表示恢复为 ccccc。

本题需要你根据压缩或解压的要求，对给定字符串进行处理。这里我们简单地假设原始字符串是完全由英文字母和空格组成的非空字符串。

**输入格式：**

输入第一行给出一个字符，如果是 C 就表示下面的字符串需要被压缩；如果是 D 就表示下面的字符串需要被解压。第二行给出需要被压缩或解压的不超过1000个字符的字符串，以回车结尾。题目保证字符重复个数在整型范围内，且输出文件不超过1MB。

**输出格式：**

根据要求压缩或解压字符串，并在一行中输出结果。

**输入样例 1：**

C
TTTTThhiiiis isssss a   tesssst CAaaa as

**输出样例 1：**

5T2h4is i5s a3 te4st CA3a as

**输入样例 2：**

D
5T2h4is i5s a3 te4st CA3a as10Z

**输出样例 2：**

TTTTThhiiiis isssss a   tesssst CAaaa asZZZZZZZZZZ

## 我的解决方案
```c
#include <stdio.h>
#include <ctype.h>
#include <string.h>

#define SIZE (1 << 20 + 10)

char newStr[SIZE];

typedef void (* solveFunction)(const char *);

void trans(int num, char **str)
{
    if (num) {
        trans(num / 10, str);
        *(*str)++ = num % 10 + '0';
    }
}

//int转换为字符串
void myItoa(int num, char *str)
{
    trans(num, &str);
    *str = '\0';
}

//压缩
void compress(const char *str)
{
    int count = 1;
    int size = 0;
    char num[12]; //重复个数的字符串版本

    for (int i = 1; i < strlen(str); ++i) {
        if (str[i] == str[i - 1]) {
            ++count;
        }
        else {
            if (count > 1) {
                myItoa(count, num);
                strcat(newStr, num);
                size += strlen(num);
                count = 1;
            }
            newStr[size++] = str[i - 1];
        }
    }
    //最后一部分
    if (count > 1) {
        myItoa(count, num);
        strcat(newStr, num);
        size += strlen(num);
    }
    newStr[size++] = str[strlen(str) - 1];
    newStr[size] = '\0';

    printf("%s", newStr);
}

//解压
void decompress(const char *str)
{
    int size = 0;

    for (int i = 0; i < strlen(str); ++i) {
        int count = 0;

        while (isdigit(str[i])) {
            count = count * 10 + str[i++] - '0';
        }
        //只有一个字符
        if (count == 0) {
            newStr[size++] = str[i];
        }
        //将字符全部解压
        while (count--) {
            newStr[size++] = str[i];
        }
    }
    newStr[size] = '\0';

    printf("%s", newStr);
}

int main(void)
{
    char str[1024];
    char choice;
    solveFunction solve[2] = { compress, decompress };

    choice = getchar();
    getchar();
    fgets(str, SIZE, stdin);
    solve[choice - 'C'](str);

    return 0;
}
```
