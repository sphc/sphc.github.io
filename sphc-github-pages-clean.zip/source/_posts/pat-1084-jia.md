---
title: PAT 1084.Broken Keyboard
mathjax: true
toc: true
categories: 'PAT题解[甲级]'
tags:
  - PAT
abbrlink: '15346e07'
date: 2018-04-15 09:47:50
---

## 题目
On a broken keyboard, some of the keys are worn out. So when you type some sentences, the characters corresponding to those keys will not appear on screen.

Now given a string that you are supposed to type, and the string that you actually type out, please list those keys which are for sure worn out.

**Input Specification:**

Each input file contains one test case. For each case, the 1st line contains the original string, and the 2nd line contains the typed-out string. Each string contains no more than 80 characters which are either English letters [A-Z] (case insensitive), digital numbers [0-9], or "_" (representing the space). It is guaranteed that both strings are non-empty.

**Output Specification:**

For each test case, print in one line the keys that are worn out, in the order of being detected. The English letters must be capitalized. Each worn out key must be printed once only. It is guaranteed that there is at least one worn out key.

**Sample Input:**

7_This_is_a_test
_hs_s_a_es

**Sample Output:**

7TI

## 我的解决方案
```cpp
#include <iostream>
#include <string>
#include <cctype>
#include <set>

//解题思路:
//用一个set good保存第二次输入中出现过的字符,这些按键是完好的
//用一个set exist保存已经输出过的字符,避免多次输出同一字符
//对原始字符串中的每一个字符,到good和exist中查找,若均未找到,
//则说明该键是坏的,并且是第一次遇到,输出之,并将其存入exist

using namespace std;

int main()
{
    set<char> good, exist; //good:打印的字符中完好的按键,exist:已经输出的字符
    string origin; //原始字符串
    int c;

    getline(cin, origin);
    while ((c = cin.get()) != EOF) {
        good.insert(toupper(c));
    }
    for (auto x : origin) {
        char tmp = toupper(x);
        if (good.find(tmp) == good.end() && exist.find(tmp) == exist.end()) {
            cout << tmp;
            exist.insert(tmp);
        }
    }
    cout << endl;

    return 0;
}
```
